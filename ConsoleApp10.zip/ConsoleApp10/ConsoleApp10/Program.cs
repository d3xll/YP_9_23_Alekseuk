﻿// 1 Задание
PrintZadanie(1);
// Локальная функция. Пример
/*Локальная функция - функция доступная только в одном классе*/
int sum = AddSumm(5, 3);
Console.WriteLine($"Локальная функция: {sum}");
int AddSumm (int x, int y)
{
    return x + y;
}
// Рекурсивная функция
/*Рекурсивная функция - функция вызывающая саму себя */
int factorial = Factorial(5);
Console.WriteLine($"Рекурсивная функция: {factorial}");
static int Factorial(int n)
{
    if (n <= 1) return 1;
    return n * Factorial(n - 1);
}




// 2 Задание. Использование switch
PrintZadanie(2);
/*switch - используется для выбора одного из мноества вариантов выполенния кода в зависимости от значения переменной day.*/
Console.WriteLine("Введите день недели (1-7):");
int day = int.Parse(Console.ReadLine());

switch(day)
{
    case 1:
        Console.WriteLine("Понедельник");
        break;
    case 2:
        Console.WriteLine("Вторник");
        break;
    case 3:
        Console.WriteLine("Среда");
        break;
    case 4:
        Console.WriteLine("Четверг");
        break;
    case 5:
        Console.WriteLine("Пятница");
        break;
    case 6:
        Console.WriteLine("Суббота");
        break;
    case 7:
        Console.WriteLine("Воскресенья");
        break;
    default: 
        Console.WriteLine("Такого дня нету!");
        break;
}

// 3 Задание.
PrintZadanie(3);
Student student = new Student("сиси пися кака", "кисп 9-23", 19, 4.6);
student.PrintInfoStudent();

// 4 задание
PrintZadanie(4);
/*Инкапсуляция - скрытие внутренних данных (name, age) с использованием модификатора private и предоставление доступа через свойства Name, Age. Это защищает данные от некорректного изменения и позволяет добавлять логику.*/

Person person = new Person();
person.Name = "хз";
person.Age = 25;
Console.WriteLine($"Имя персонажа: {person.Name}, возраст персонажа: {person.Age}");

// 5 задание
PrintZadanie(5);
/*Наследование - позволяет наследовать свойства и методы от класса. Это позволяет избежать дубляжа кода и использовать код базового (класс от которого наследуютс) класса.*/
Dog dog = new Dog();
dog.Name = "фимозик";
dog.Eat();
dog.Bark();

// 6 задание
PrintZadanie(6);
/*Полиморфизм - возможность использовать метод через базовый класс, но получить разное поведение от разных классов.*/
dog.MakeAnySound();

// Функция для пометки задания
void PrintZadanie(int id)
{
    Console.WriteLine();
    Console.ForegroundColor = ConsoleColor.Green;
    Console.WriteLine($"{id} Задание");
    Console.ResetColor();

}