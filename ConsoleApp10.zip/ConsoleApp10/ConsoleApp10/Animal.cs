﻿class Animal
{
    public string Name { get; set; }

    public void Eat()
    {
        Console.WriteLine($"{Name} ест");
    }

    // Пример полиморфизма
    public virtual void MakeAnySound()
    {
        Console.WriteLine("Какой-то звук типо");
    }
}

class Dog : Animal
{
    public void Bark()
    {
        Console.WriteLine($"{Name} лает");
    }

    // Пример полиморфизма в наследуемом классе
    public override void MakeAnySound()
    {
        Console.WriteLine("гав гав оу ес");
    }
}