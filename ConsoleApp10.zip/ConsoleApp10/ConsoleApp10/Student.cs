﻿class Student
{
    private string fullName;
    private string group;
    private int age;
    private double perfomance;

    public Student(string fullName, string group, int age, double perfomance)
    {
        this.fullName = fullName;
        this.group = group;
        this.age = age;
        this.perfomance = perfomance;
    }

    public void PrintInfoStudent()
    {
        Console.WriteLine($"ФИО: {fullName}");
        Console.WriteLine($"Группа: {group}");
        Console.WriteLine($"Возраст: {age}");
        Console.WriteLine($"Успеваемость: {perfomance}");
    }
}